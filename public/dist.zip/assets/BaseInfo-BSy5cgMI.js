import{_ as o}from"./BaseInfo.vue_vue_type_script_setup_true_lang-B-XUrTWK.js";import"./index-CXJ6mZiv.js";import"./vue-BNadgXYb.js";export{o as default};
